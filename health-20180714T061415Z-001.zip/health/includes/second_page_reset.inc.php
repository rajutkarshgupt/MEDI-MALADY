<?php

header("Location: ../second_page.php");
exit();


?>