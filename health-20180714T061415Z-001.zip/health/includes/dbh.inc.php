<?php

$dbServername="localhost";
$dbUsername="root";
$dbPassword="shubhi";
$dbName="health";
$conn=mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);

?>