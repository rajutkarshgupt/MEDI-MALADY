<!DOCTYPE html>
<html>
<head>

<style>
img{
	height:300px;
	width:400px;
}

h1{
	text-align:center;
}
p{
	font-size:30px;
}

</style>



</head>
<body>
<p>
<img src="pics of disease/Arthritis/image.jpg"></img>
<a href="find.php" >TO GET LOCATION OF NEARBY DOCTOR CLICK HERE</a>
</p>
</body>
</html>