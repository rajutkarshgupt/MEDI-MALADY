

<html>


<head>
<style>

body{
	text-align:center;
	padding-top:200px;
	background-color:#C0C0C0;
}
</style>

</head>
<body>
<h2>ABOUT US</h2>
This website is made by students of IIIT Lucknow and IIIT Allahabad for the well-being of every individual who must be aware of the disease they are going through and they must have the knowledge of the nutrients they need to keep there body healthy.<br> We have tried our best to make our website user-friendly and easy to use without getting much information from the user.<br> Our objective is to provide the best information related to disease, nutrients and its diet too. We hope you like our website. Thank you for coming! 
</body>

</html>