<!DOCTYPE html>
<html>
<head>

<style>
img{
	height:300px;
	width:400px;
}



</style>



</head>
<body>

<img src="pics of disease/alzhimer/download.jpg"></img>

</body>
</html>