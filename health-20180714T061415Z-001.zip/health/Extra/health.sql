-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2018 at 02:55 PM
-- Server version: 5.5.17
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health`
--

-- --------------------------------------------------------

--
-- Table structure for table `nutrients`
--

CREATE TABLE `nutrients` (
  `Disease_type` varchar(255) NOT NULL,
  `Nutrient 1` varchar(255) NOT NULL,
  `Nutrient 2` varchar(255) NOT NULL,
  `Nutrient 3` varchar(255) NOT NULL,
  `Nutrient 4` varchar(255) NOT NULL,
  `Nutrient 5` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nutrients`
--

INSERT INTO `nutrients` (`Disease_type`, `Nutrient 1`, `Nutrient 2`, `Nutrient 3`, `Nutrient 4`, `Nutrient 5`) VALUES
('Maternal Disease', 'Calcium', 'Vitamin D', 'Potassium', 'Fiber', 'Iron'),
('Child Health', 'Protein', 'Carbohydrates', 'Fats', 'Calcium', 'Iron'),
('HIV/AIDS', 'Beta-carotene', 'Protein', 'Carbohydrates', 'Selenium', 'Vitamin A,B,C,E'),
('Tuberculosis', 'Zinc', 'Vitamin A,C,D,E', 'Selenium', 'Iron', 'Cholesterol'),
('Malaria', 'Zinc', 'Protein', 'Fat', 'Vitamin A,B,C', 'Protein'),
('Cholera', 'Fiber', 'Vitamin C', 'Potassium', 'Manganese', 'Iron'),
('Influenza', 'Vitamin C,D', 'Probiotics', 'Epicor', 'Selenium', 'Amino Acid'),
('Meningitis', 'Fatty Acid', 'Vitamin A,B,C,D,E,K', 'Beta-carotene', 'Calcium', 'Phosphorus'),
('Arthritis', 'Protein', 'Fat', 'Fatty Acid', 'Vitamin B', 'Calcium'),
('Allergy', 'Magnesium', 'Vitamin C,E', 'Protein', 'Fatty Acid', 'Calcium'),
('Sexually Transmitted Disease', 'Fiber', 'Vitamins', 'Beta- carotene', 'Fatty Acid', 'Selenium'),
('Alcohol Control', 'Protein', 'Zinc', 'Vitamin B,C', 'Calcium', 'Potassium'),
('Liver Disease', 'Iron', 'Vitamin A,B,C,D,E', 'Fiber', 'Potassium', 'Magnesium'),
('Water and Sanitation', 'Folic Acid', 'Calcium', 'Vitamin B,D', 'Fatty Acid', 'Magnesium'),
('Overweight', 'Calcium', 'Vitamin B,C,K', 'Zinc', 'Protein', 'Amino Acid'),
('Heart Disease', 'Potassium', 'Vitamin C,E,K', 'Fatty Acid', 'Folic Acid', 'Carbohydrate'),
('Stroke', 'Fiber', 'Potassium', 'Folate', 'Vitamin C', 'Calcium'),
('Respiratory Infections', 'Vitamin A,C,E', 'Folate', 'Fatty Acid', 'Magnesium', 'Selenium'),
('Pulmonary Disease', 'Vitamin C,D,E\r\n', 'Flavonoids', 'Magnesium', 'Calcium', 'Potassium'),
('Trachea, Bronchus and Lung Cancers', 'Vitamin A,C,E', 'Selenium', 'Beta-carotene', 'Fatty Acid', 'Protein'),
('Diabetes Mellitus', 'Carbohydrate', 'Protein', 'Fat', 'Fiber', 'Magnesium'),
('Alzheimer', 'Fiber', 'Protein', 'Vitamin C,E', 'Calcium', 'Beta-carotene'),
('Dehydration due to Diarrhea', 'Potassium', 'Calcium', 'Magnesium', 'Phosphorus', 'Vitamin C'),
('Cirrhosis', 'low-fat diets', 'Antioxidant', 'Vitamin B', 'Amino Acid', 'Probiotic Treatment');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `user_first` varchar(255) NOT NULL,
  `user_last` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_uid` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `user_first`, `user_last`, `user_email`, `user_uid`, `user_password`) VALUES
(1, 'hkfc', 'agarwal', 'abcd@gmail.com', 'gdxzh', '$2y$10$77Y0MaT3kA.ylR61DQJONeMsw93Ll9BrAdIyOFevmajkZ2Bf6m'),
(2, 'hkfc', 'hkfc', 'angleshubhi456@iiita.ac.in', 'jgckh', '$2y$10$y6HTPDZiSEtuwCGRk7854u34cdnLCkNd2nHm8eEDbwNAVVm/.RFWS'),
(3, 'shubhi', 'agarwal', 'abcd@gmail.com', '1234', '$2y$10$njC6YJXnXwT7Naym/xPNqu0149ikFfv7qoh6HlKA1nDvd274Ovt.S'),
(4, 'tyeryt', 'jgfjgf', 'abcd@gmail.com', 'utrdytrd', '$2y$10$Gb6lSl7WwSXi8DnaiWcJYO76LNSERFoEvHDFpR8T0XZ.V1WIHRA0y'),
(5, 'hkgc', 'sdg', 'angleshubhi456@iiita.ac.in', 'hfdzxg', '$2y$10$w/svi89Wj9HQ22/8m2.yiOwOC4mSTQ/8j.MYt51vxagrs8oQ4U0ri');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
