<?php
//$link="https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=19.0760,72.8777&radius=500&type=doctor&key=AIzaSyDtRVL608rSdYKjmMIlgRNwRgkqDU0zhi0";
$cont = file_get_contents("https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=19.0760,72.8777&radius=500&type=doctor&key=AIzaSyD6PyURM2qCatrH37nHiDfDzZPlJVaxvLU");

$obj = json_decode($cont,true);
for($i=0;$i<30;$i++)
               {
                  if(!isset($obj["results"][$i]["name"]))
                  {
                    echo "<b>We were able to show only these many results.</b><br><br><br><br>";
                    break;
                  }
                  else
                  {
                   $place_ref=$obj["results"][$i]["place_id"];
                          $place_details_url="https://maps.googleapis.com/maps/api/place/details/json?placeid=".$place_ref.'&key=AIzaSyD6PyURM2qCatrH37nHiDfDzZPlJVaxvLU';
                           $details_cont = file_get_contents($place_details_url);
                           $details_obj = json_decode($details_cont,true); 

                          echo '
                          <div class="container-fluid">
                              <div class="jumbotron3" style="background-color:#9CDEBA;font-size:20px;margin-left:20px;padding-left:20px;padding-top:25px;padding-bottom:25px;">
                                  <b>'.$obj["results"][$i]["name"].
                              '</div></b><br><br>';
                          echo '<ul type="square" >
                                 <li><b><i>Address:'.$obj["results"][$i]["vicinity"].'</i></b><br></li>';

                            if (isset($details_obj["result"]["formatted_phone_number"])) 
                                  {
                                       echo '<li><b><i>Contact:'.$details_obj["result"]["formatted_phone_number"].'</i></b><br></li>'  ;                                 
                                 }
                            if(isset($details_obj["result"]["website"]))    
                            {
                                       echo '<li><b><i>Website:<a target="_blank" href='.$details_obj["result"]["website"].'>Open in a new tab. </a></i></b><br></li>';
                            } 
                                 
                                 if(isset($details_obj["result"]["rating"]))
                            {
                                       echo '<li><b><i>Ratings:'.$details_obj["result"]["rating"].'</i></b><br></li>';

                            }
                            
                            if(isset($details_obj["result"]["url"]))
                            {
                                      echo '<li><b><i>Find on map:<a target="_blank" href='.$details_obj["result"]["url"].'>Open in a new tab.</a></i></b><br></li>';

                            }
									echo "</ul><br><hr></div>";
				  }
			   }
?>
<!DOCTYPE html>
<html>
<head>
<title></title>

<style>
*{
	margin:0px;
	padding:0px;
}
#map{
	width:100%;
	height:500px;
}
</style>
</head>
<body>
<div id="map">


</div>
<script>
var x = document.getElementById('map');
var llt,llx;
  function getLocation()
  {
	  if(navigator.geolocation)
		  navigator.geolocation.getCurrentPosition(showPosition);
	  else
		  x.innerHTML="browser not supporting";
  }
  function showPosition(position)
  {
	  llt=position.coords.latitude;
	  llx=position.coords.longitude;
	  x.innerHTML = "latitude ="+llt;
	  x.innerHTML += "<br>"
	  x.innerHTML += "Longitude ="+llx;  
  }
function initMap(position)
{
	var location={lat: 20.5945,lng: 78.9690};
	var map1= new google.maps.Map(document.getElementById("map"),{
		
		zoom: 4,
		center: location
		
	});
	var marker = new google.maps.Marker({
          position: location,
          map: map1
        });
}



</script>

</body>

</html>