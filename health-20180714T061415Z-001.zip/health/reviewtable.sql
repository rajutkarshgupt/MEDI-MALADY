-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2018 at 01:47 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medipas`
--

-- --------------------------------------------------------

--
-- Table structure for table `reviewtable`
--

CREATE TABLE `reviewtable` (
  `medicine` longtext NOT NULL,
  `user` longtext NOT NULL,
  `review` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviewtable`
--

INSERT INTO `reviewtable` (`medicine`, `user`, `review`) VALUES
('Amoxilin', 'Utkarsh', 'This drug gives headache after about 2000mg in 24 hours and the headache persists for about 36 hours'),
('Paracetamol', 'Utkarsh', 'This drug gives headache after about 2000mg in 24 hours and the headache persists for about 36 hours'),
('Amoxicillin', 'Utkarsh', 'Novamoxin-Amoxicillin(3 tablets x 500 mg/day)had a severe allergic reaction (bad hives,itching,rash)'),
('\r\nAspirin', 'Anjali ', 'This medicine was too gud and i liked it.'),
('\r\nAspirin', 'Anjali ', 'This medicine was too gud and i liked it.'),
('Aspirin', '', ''),
('Aspirin', '', ''),
('Aspirin', '', ''),
('Aspirin', '', ''),
('Aspirin', 'Anjali Pandey', 'nkakja'),
('Aspirin', 'Anjali Pandey', 'this medicine is good for headache '),
('Zoloft', 'Anjali Pandey', 'this was beneficial'),
('Zoloft', 'utkarsh', 'This '),
('Zoloft', 'Anjali Pandey', 'it was okay '),
('Azithromycin', 'Anjali Pandey', 'nice '),
('Azithromycin', 'utkarsh', 'good'),
('Azithromycin', 'utkarsh', 'good'),
('Azithromycin', 'Anjali Pandey', 'niceeee'),
('Azithromycin', 'apapappl', 'ajoajiojaij'),
('Zoloft', 'Manisha Meena ', 'nice medicine'),
('Zoloft', 'Shubhi agarwal', 'I was highly relieved during my upset stomach '),
('Zoloft', 'Shubhi agarwal', 'I was highly relieved during my upset stomach '),
('Zoloft', 'Anjali ', 'This medicine was really nice\r\n'),
('Zoloft', 'Anjali ', 'This medicine was really nice\r\n');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
