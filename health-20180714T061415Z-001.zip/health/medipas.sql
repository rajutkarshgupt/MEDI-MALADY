-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2018 at 08:28 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medipas`
--

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `name` varchar(255) NOT NULL,
  `commonbrand` varchar(255) NOT NULL,
  `genericname` varchar(255) NOT NULL,
  `uses` varchar(255) NOT NULL,
  `contents` varchar(255) NOT NULL,
  `effects` varchar(255) NOT NULL,
  `misseddosage` varchar(255) NOT NULL,
  `authorisedmanufactures` varchar(255) NOT NULL,
  `analysis` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`name`, `commonbrand`, `genericname`, `uses`, `contents`, `effects`, `misseddosage`, `authorisedmanufactures`, `analysis`) VALUES
('Aripiprazole', 'Abilify', 'Aripiprazole', 'to treat certain mental/mood disorder, and irritability associated with autistic disorder', 'sertraline, selective serotonin reuptake inhibitor (SSRI),aripiprazole.', 'Dizziness, lightheadedness, drowsiness, nausea, vomiting, tiredness, n, weight gain, constipation, headache', 'If it is near the time of the next dose, skip the missed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'OTSUKA PHARMACEUTICAL (HK) LTD', 'Terrible made me clench my teeth and rock back & forth. Two yrs later I still do it. Terrible side effects for me. not recommended by me.'),
('Aspirin', 'Children\'s Aspirin', 'Aspirin', 'reduce fever and  moderate pain such as muscle aches, toothaches, common cold, and headaches.', '90% acetylsalicylic acid with a minor amount of inert fillers and binders.', 'Upset  bruising/bleeding, difficulty hearing, ringing ears,  vomiting, unexplained tiredness, dizziness, dark urine, yellowing eyes/skin.', 'If it is near the time of the next dose, skip the missed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'Bayer healthcare llc,Harvest Pharmaceuticals Inc,Kaiser Foundation Hospital', 'Works well taken with warm water enter the blood stream faster .it works faster if taken in the powder form,doesn have to disolve.'),
('Atenolol', 'Tenormin', 'Atenolol', 'to treat high blood pressure (hypertension). Lowering high blood pressure helps prevent strokes, heart attacks, and kidney problems.', 'maize starch,gelatin,heavy magnesium carbonate,magnesium stearate.', 'Dizziness, lightheadedness, tiredness, and nausea may occur. If any of these effects persist or worsen, tell your doctor or pharmacist promptly.', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'FORTUNE NATIONAL (HONG KONG) LIMITED,APT PHARMA LIMITED.', 'Have been taking this medication for a long time, 50mg. My blood pressure got much better so I started taking only 1/2 a pill and it stays at a great level.'),
('Azithromycin', 'Zithromax', 'Azithromycin', 'bacterial infections, macrolide-type antibiotic, stopping the growth of bacteria.', 'dibasic calcium phosphate anhydrous, pregelatinized starch, sodium croscarmellose, magnesium stearate, sodium lauryl sulfate.', 'Stomach upset, diarrhea/loose stools, nausea, vomiting, or abdominal pain .', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'CEUTICAL TRADING COMPANY LIMITED,DAWNRAYS PHARMA (HONG KONG) LTD,MAINBOND PHARMACEUTICAL CO., LTD.', 'Prescribed the 5 dose pack for an infected epidermal cyst. Mild side-effect of acid stomach, but manageable.'),
('Citalopram HBR', 'Celexa', 'Citalopram', 'to treat depression,improve your energy level and feelings of well-being. ', 'mannitol, microcrystalline cellulose, colloidal silica anhydrous, magnesium stearate.', 'Nausea, dry mouth, loss of appetite, tiredness, drowsiness, sweating, blurred vision, and yawning.', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'JINDUN PHARMA (H.K.) LIMITED', 'No doubt, it started working after about one week. I had serious doubts it would help alleviate my depression, however, it works!'),
('Duloxetine HCL', 'Cymbalta', 'Duloxetine', 'mood, sleep, appetite, and energy level, and decrease nervousness,decrease pain due to certain medical conditions.', 'serotonin and norepinephrine reuptake inhibitor (SSNRI).', 'Nausea, dry mouth, constipation, loss of appetite, tiredness, drowsiness, or increased sweating may occur. ', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'ALVOGEN EMERGING MARKETS HOLDINGS LIMITED,NOVARTIS PHARMACEUTICALS (HK) LIMITED', 'Became a compulsive spender. After stopping it I have severe anxiety which I never experienced before.'),
('Escitalopram Oxalate', 'Lexapro', 'Escitalopram Oxalate', ' to treat depression and anxiety, to restore the balance of serotonin in the brain.', 'sorbitol, purified water, citric acid, sodium citrate, malic acid, glycerin, propylene glycol.', 'Nausea, dry mouth, trouble sleeping, constipation, tiredness, drowsiness, dizziness, and increased sweating.', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'Lundbeck HK Limited', 'I was put on this medication for depression.I had to stop as I had gained so much weight.I went from 103 lbs.to 161 lbs..'),
('Fluoxetine HCL', 'Prozac, Sarafem', 'Fluoxetin', 'to treat depression, panic attacks, obsessive compulsive disorder, bulimia, premenstrual syndrome.', 'fluoxetine hydrochloride ,starch, gelatin, silicone, titanium dioxide, iron oxide.', 'Nausea, drowsiness, dizziness, anxiety, trouble sleeping, loss of appetite, tiredness, sweating, or yawning .', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'AUROBINDO PHARMA LIMITED,THE INTERNATIONAL MEDICAL COMPANY LIMITED.', 'Only had one or two bad patches while of prozac. Made me unable to achieve orgasm.'),
('Hydrocodone-Acetaminophen', 'Lortab, Norco, Vicodin', 'Hydrocodone-Acetaminophen', ' to relieve moderate to  pain, contains an opioid pain reliever  and a non-opioid pain reliever.', 'opioid pain medication, hydrocodone, with paracetamol (acetaminophen).', 'Nausea, vomiting, constipation, lightheadedness, dizziness, or drowsiness, constipation, eat a diet adequate in fiber, drink plenty of water, and exercise.', 'If it is near the time of the next dose, skip the missed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'Vintage Pharmaceuticals (or Qualitest), Mallinckrodt, VistaPharm, Watson Laboratories, Mylan Institutional, and Aidapak Services.', 'I take Vicodin for bulging discs, deterioration of the spine and arthritis in my lumbar.  I would not be able to get out of bed or off the couch if not for this drug.'),
('Meloxicam', 'Mobic, Vivlodex', 'Meloxicam', 'arthritis,reduces pain, swelling, and stiffness of the joints.', 'titration method with Oleic acid as oil phase,gel matrix that is Carbopol981 NF and Carbopol 974 P NF.', 'Stomach upset, nausea, dizziness, or diarrhea may occur. If any of these effects persist or worsen.', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'REICH PHARM LIMITED,HONG KONG MEDICAL SUPPLIES LTD,MAINBOND PHARMACEUTICAL CO., LTD.', 'Took meloxicam for 3 weeks with food.My stomach has been upset with bloating and some diarrhea.'),
('Naproxen', 'EC-Naprosyn', 'Naproxen', 'to relieve pain  such as headaches, muscle aches, tendonitis, dental pain, and menstrual cramps, swelling, and joint stiffness .', 'Naproxen sodium,croscarmellose sodium, iron oxides, povidone and magnesium stearate.', 'Upset stomach, nausea, heartburn, headache, drowsiness, or dizziness. ', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule.', 'UNITED ITALIAN CORP (HK) LTD,ACTAVIS HONG KONG LIMITED,VICKMANS LABORATORIES LTD,SUNTOL MEDICAL LIMITED.', 'This really worked for me. I\'ve had three back surgeries and It\'s good to have it around.'),
('Oxycodone HCL', 'Roxicodone Intensol', 'Oxycodone', 'relieve severe ongoing pain (such as due to cancer), brain to change how your body feels', 'oxycodone hydrochloride and acetaminophen ', 'Nausea, vomiting, constipation, dry mouth, weakness, sweating, lightheadedness, dizziness, or drowsiness may occur', 'Take your next dose at the regular time. Do not double the dose to catch up.', 'MUNDIPHARMA (HONG KONG) LIMITED.', '6, 5mg percoset a day, sometimes its ok, other times its not enough.When I was on Oxycontin, my pain was managed very well.'),
('Prednisone', 'Deltasone', 'Prednisone', 'arthritis, blood disorders, breathing problems, severe allergies, skin diseases, cancer, eye problems, and immune system disorders.', 'lactose monohydrate, magnesium stearate, microcrystalline cellulose, pregelatinized starch, sodium starch glycolate.', 'Nausea, vomiting, loss of appetite, heartburn, trouble sleeping, increased sweating, or acne .', 'If you are taking this medication on a different schedule than a daily one , ask your doctor ahead of time about what you should do if you miss a dose.', 'Healthy Life Pharma PVT.LTD.,Zuche Pharmaceuticals PVT.LTD.', 'Taking a Medrol dose pack for sinusitis and bronchitis, the pressure relief is unbelievable.'),
('Quetiapine FUMARATE', 'Seroquel', 'Quetiapine', 'to treat certain mental/mood conditions such as schizophrenia, bipolar disorder, sudden episodes of mania or depression associated with bipolar disorder.', 'hemifumarate is in particular from about 51 to 70% by weight,a methacrylic acid copolyme.', 'Constipation, drowsiness, upset stomach, tiredness, weight gain, blurred vision, or dry mouth.', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'HONG KONG MEDICAL SUPPLIES LTD,IVAX ASIA LTD,THE INTERNATIONAL MEDICAL COMPANY LIMITED.', 'Has been effective but as I have increased dosage (400 mg) there has been weight gain. I have worked with my endocrinologist (I also have diabetes) and that has become less of a concern.'),
('Simvastatin', 'Zocor', 'Simvastatin', 'proper diet to help lower \"bad\" cholesterol and fats and raise \"good\" cholesterol (HDL) in the blood.', 'Aspergillus terreus,lactone, is hydrolyzed to the corresponding ?-hydroxyacid form.', 'Remember that your doctor has prescribed this medication because he or she has judged that the benefit to you is greater than the risk of side effects.', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'CNW FAR EAST LIMITED,HONG KONG MEDICAL SUPPLIES LTD,IVAX ASIA LTD.', 'Muscle aches started after years of use - 20mG. Prior I had unexplained peripheral neuropathy which several neurological tests . Off the drug and feeling better.'),
('Tadalafil Tablet', 'Cialis', 'Tadalafil', 'to treat male sexual function problems,does not protect against sexually transmitted diseases (such as HIV, hepatitis B, gonorrhea, syphilis).', 'Dapoxetine Hydrochloride .', 'Headache, stomach upset, back pain, muscle pain, stuffy nose, flushing, or dizziness. ', 'If it is near the time of the next dose, skip the missed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'NOVARTIS PHARMACEUTICALS (HK) LIMITED,HONG KONG MEDICAL SUPPLIES LTD.', 'took 20mg tablet I got as a sample from Dr. after 1/2 hour had solid erection.Only side effect was some mild facial flushing.'),
('Tramadol HCL', 'Ultram', 'Tramadol', 'to relieve pain, brain to change how your body feels and responds to pain.', 'five doses of acetaminophen 300 mg with codeine phosphate 30 mg', 'Nausea, vomiting, constipation, lightheadedness, dizziness, drowsiness, or headache may occur.', 'Not applicable.', 'MEKIM LTD,STADA PHARMACEUTICALS (ASIA) LTD,HIND WING CO LTD,HONG KONG PUI\'S PHARMACEUTICALS COMPANY LIMITED.', 'I have pain in my intestines caused by side effects of hormone therapy. Tramadol works great for me. Only one 50mg tablet a day takes away all pain.'),
('Trazodone HCL', 'Desyrel', 'Trazodone', 'to treat depression, appetite, decrease anxiety and insomnia related to depression.', 'microcrystalline cellulose, FD&C Yellow No. 6 (aluminum lake), magnesium stearate, pregelatinized starch, and stearic acid.', 'Nausea, vomiting, drowsiness, dizziness, lightheadedness, headache,or change in sexual interest/ability may occur.', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule.', 'Watson Labs, Apotex Inc., Alvogen, Pliva, Teva, Mutual Pharm, Matrix Labs Ltd.', 'I was given by psychiatrist to help with sleep, and did.'),
('Zoloft', '-', 'Sertraline', 'to treat depression, panic attacks, compulsive disorder, post-traumatic stress disorder, social anxiety disorder,premenstrual syndrome.', 'Disulfiram Contraindication', 'Nausea, dizziness, drowsiness, dry mouth, loss of appetite, increased sweating, diarrhea, upset stomach.', 'If it is near the time of the next dose, skip themissed dose and resume your usual dosing schedule. Do not double the dose to catch up.', 'JINDUN PHARMA (H.K.) LIMITED,THE INTERNATIONAL MEDICAL COMPANY LIMITED,TRENTON-BOMA LTD.', 'Zoloft makes me cheerful, relaxed, undepressed, not anxious and least side effects.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
