<!DOCTYPE html>
<html>
<head>
<title>Medi-malady</title>
</head>
<style>
body{
background-color:#add8e6;
}
</style>
<body>
<?php


if(isset($_POST['submit'])) {

	$conn=mysqli_connect('localhost','root','shubhi','health');

	$des = $_POST['disease'];
	$sql1="select Information from nutrients where Disease_type='$des'";
	$sql2="select Nutrient1 from nutrients where Disease_type='$des'";
	$sql3="select Nutrient2 from nutrients where Disease_type='$des'";
	$sql4="select Nutrient3 from nutrients where Disease_type='$des'";
	$sql5="select Nutrient4 from nutrients where Disease_type='$des'";
	$sql6="select Nutrient5 from nutrients where Disease_type='$des'";
	if($result1=mysqli_query($conn,$sql1))
	{
		while($row1 = mysqli_fetch_array($result1))
		echo $row1[0]."<br>"."<br>";
	}
	
	if($result2=mysqli_query($conn,$sql2))
	{
		while($row1 = mysqli_fetch_array($result2))
		echo $row1[0]."<br>";
	}
	if($result3=mysqli_query($conn,$sql3))
	{
		while($row1 = mysqli_fetch_array($result3))
		echo $row1[0]."<br>";
	}
	if($result4=mysqli_query($conn,$sql4))
	{
		while($row1 = mysqli_fetch_array($result4))
		echo $row1[0]."<br>";
	}
	if($result5=mysqli_query($conn,$sql5))
	{
		while($row1 = mysqli_fetch_array($result5))
		echo $row1[0]."<br>";
	}
	if($result6=mysqli_query($conn,$sql6))
	{
		while($row1 = mysqli_fetch_array($result6))
		echo $row1[0]."<br>";
	}
}


?>
</body>
</html>