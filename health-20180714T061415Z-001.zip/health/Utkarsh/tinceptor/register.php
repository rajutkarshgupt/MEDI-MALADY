<!--
All eode is under the GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007.
-->

<?php 

include("config.php"); 

// connect to the mysql server
$link = mysqli_connect("localhost" , "root")
or die ("Could not connect to mysql because ".mysqli_error($link));

// select the database
mysqli_select_db($link,"test")
or die ("Could not select database because ".mysqli_error($link));

// check if the username is taken
$acc = "table2";
$check = "select id from $acc where user = '".$_POST['username']."';";
$qry = mysqli_query($link,$check) or die ("Could not match data because ".mysqli_error($link));
$num_rows = mysqli_num_rows($qry); 
if ($num_rows != 0) { 
echo "Sorry, there the username '".$_POST['username']."' is already taken.<br>";
echo "<a href=register.html>Try again</a>";
exit; 
} else {
$khaata = $_POST['username'];
$sql = "CREATE TABLE $khaata (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
year INT(50) NOT NULL,
month INT(50) NOT NULL,
dat INT(50) NOT NULL,
day VARCHAR(50) NOT NULL,
nam VARCHAR(50) NOT NULL,
amt INT(50) NOT NULL,
reg_date TIMESTAMP
)";

if ($link->query($sql) === FALSE) 
    echo "Error creating table: " . $conn->error;



$insert = mysqli_query($link,"insert into $acc values ('NULL',
'".$_POST['username']."',
'".$_POST['email']."',
'".$_POST['password']."')")
or die("Could not insert data because ".mysqli_error($link)." <br> <a href='register.html'>TRY AGAIN</a>");

// print a success message
echo "Your user account has been created!<br>"; 
echo "Now you can <a href='login.html'>log in</a>"; 
}

?>
