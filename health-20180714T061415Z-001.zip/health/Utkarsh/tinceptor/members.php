<!--
All eode is under the GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007.
-->

<?php 

include("config.php"); 

// connect to the mysql server
$link = mysqli_connect("localhost" , "root")
or die ("Could not connect to mysql because ".mysqli_error($link));

// select the database
mysqli_select_db($link,"test")
or die ("Could not select database because ".mysqli_error($link));

// check if the username is taken

$dbtable = $_POST['khaata'];

$check = "select id from $dbtable where nam = '".$_POST['email']."' ;" ;
$qry = mysqli_query($link,$check) or die (mysqli_error($link)."ACCOUNT WITH NO SUCH USERNAME EXIST <br><br><a href='members.html'> TRY AGAIN </a> WITH CORRECT USERNAME <br><br> IF WANT TO START FRESH ACCOUNT <a href='register.html'> CREATE ACCOUNT </a>");
$num_rows = mysqli_num_rows($qry); 
if ($num_rows != 0) { 
echo "Alraedy Entered.<br>";
echo "<a href=members.html>Try again</a>";
exit; 
} else {

// insert the data
$insert = mysqli_query($link,"insert into $dbtable values ('NULL',
'".$_POST['year']."',
'".$_POST['month']."',
'".$_POST['dat']."',
'".$_POST['day']."',
'".$_POST['email']."',
'".$_POST['amount']."','NULL')")
or die("<br><a href='members.html'> TRY AGAIN </a>".mysqli_error($link));

// print a success message
echo "Entered!<br>";
//$dbtable='".$_POST['khaata']."';
$khaata = $_POST['khaata'];
$query = "SELECT SUM(amt) FROM $khaata ;";
$query2 = "SELECT SUM(amt) FROM $khaata WHERE month ;";
$q = "SELECT * FROM $khaata ;";
$qry = mysqli_query($link,$q)
or die ("<br><a href='members.html'> TRY AGAIN </a>".mysqli_error($link));
$num_rows = mysqli_num_rows($qry); 
echo "<br>TOTAL EXPENDITURE TILL NOW :- <br>";
if ($num_rows <= 0)
	echo " Rs. 0<br>";
			if($sql = mysqli_query($link,$query))
			{
				$val = mysqli_fetch_assoc($sql);
				echo " Rs. ";
				foreach($val as $val)
					print_r($val);
		echo "<br><br>";
			}
echo "<a href='members.html'>ENTER NEXT</a> <br> <a href='index.html'>LOG OUT</a> "; 
}

?>
