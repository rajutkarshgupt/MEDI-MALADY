<?php

include("config.php"); 

// connect to the mysql server
$link = mysqli_connect("localhost" , "root")
or die ("Could not connect to mysql because ".mysqli_error($link));

// select the database
mysqli_select_db($link,"test")
or die ("Could not select database because ".mysqli_error($link));
$acc = "table2";
$match = "select id from $acc where user = '".$_POST['username']."'
and pwd = '".$_POST['password']."';"; 
$qry = mysqli_query($link,$match)
or die ("Could not match data because ".mysqli_error($link)." <br> <a href=login.html>Try again</a>");
$num_rows = mysqli_num_rows($qry); 

if ($num_rows <= 0) { 
echo "Sorry, there is no username $username with the specified password.<br>";
echo "<a href=login.html>Try again</a>";
exit; 
} else {

setcookie("loggedin", "TRUE", time()+(3600 * 24));
//setcookie("site_username", "$username");
echo "You are now logged in! <br>";
$khaata = $_POST['username'];
$query = "SELECT SUM(amt) FROM $khaata ;";
$query2 = "SELECT SUM(amt) FROM $khaata WHERE month ;";
$q = "SELECT * FROM $khaata ;";
$qry = mysqli_query($link,$q)
or die ("Could not fetch data because ".mysqli_error($link));
$num_rows = mysqli_num_rows($qry); 
echo "<br>TOTAL EXPENDITURE TILL NOW :- <br> Rs. ";
if ($num_rows <= 0)
	echo " 0<br>";
			if($sql = mysqli_query($link,$query))
			{
				$val = mysqli_fetch_assoc($sql);
				foreach($val as $val){
					print_r($val);
}
		echo "<br>";
			}
echo "<br><a href=members.html>REGULAR ENTRY</a> <br><br> <a href=1.html>EXPENDITURE</a>>";
}
?>
