<!--
All eode is under the GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007.
-->

<?php 

include("config.php"); 

// connect to the mysql server
$link = mysqli_connect("localhost" , "root")
or die ("Could not connect to mysql because ".mysqli_error($link));

// select the database
mysqli_select_db($link,"medicine")
or die ("Could not select database because ".mysqli_error($link));

// check if the username is taken
$acc = "reviewtable";
$check = "select user,review from $acc where medicine = '".$_POST['med']."';";
$result = mysqli_query($link,$check) or die ("Could not match data because ".mysqli_error($link));
if (!$result) {
    echo "Could not successfully run query ($sql) from DB: " . mysql_error();
    exit;
}

if (mysql_num_rows($result) == 0) {
    echo "No reviews yet, Be the FIRST ONE review medicine";
    exit;
}

while ($row = mysql_fetch_assoc($result)) {
    echo $row["user"];
    echo $row["review"];
}

mysql_free_result($result);
if($_GET['submit'])
{
	$insert = mysqli_query($link,"insert into $acc values (
	'".$_POST['med']."',
	'".$_POST['user']."',
	'".$_POST['review']."')")
	or die("Could not submit review because ".mysqli_error($link));

	// print a success message
	echo "Thanks for your precious review!<br>";
} 
 
}

?>
