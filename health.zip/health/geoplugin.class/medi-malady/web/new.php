<?php
header("Location: ../web/single.php");
 exit();
 ?>
