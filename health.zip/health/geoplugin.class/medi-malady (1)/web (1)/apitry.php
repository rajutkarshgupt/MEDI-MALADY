<?php
$arrContextOptions=array(
    "ssl"=>array(
        "verify_peer"=>false,
        "verify_peer_name"=>false,
    ),
);
 $cont = file_get_contents("https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=25.43184,81.771225&radius=10000&type=doctor&key=AIzaSyD6PyURM2qCatrH37nHiDfDzZPlJVaxvLU", false, stream_context_create($arrContextOptions));
 print_r($cont);
?>
