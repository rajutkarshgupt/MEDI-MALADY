

<html>


<head>
<style>
body{
	text-align:center;
	padding-top:200px;
	background-color:#C0C0C0;
}


</style>

</head>
<body>
<h2>WE ARE AVAILABLE 24*7 HOURS!!</h2>

<h4>CONTACT US:123-567832</h4>
<h4>Email Us:lit2016036@iiita.ac.in</h4>
</body>

</html>