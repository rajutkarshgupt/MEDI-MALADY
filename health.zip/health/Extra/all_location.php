<!DOCTYPE html>
<html>

<head>



</head>
<body>
<form class="get_location">
ENTER YOUR CITY<input type="text" name="city"></input>
</form>
</body>


</html>