<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>HEALTHY-WEALTHY</title>

<style>
li{
	list-style-type:none;
	background-color:#808080;
	display:inline-block;
	font-size:30px;
	float:right;
	padding-right:15px;
	padding-left:15px;
}
li a{
	text-decoration:none;
	color:black;
}
body{

}
img{
	height:400px;
	width:400px;
	
}
marquee{
	font-size:40px;
	font-family:arial;
}
p{
	font-size:30px;
}
form{
	padding-right:180px;

}
form button{
	float:right;
	position:relative;
	width:170px;
	height:30px;
}
</style>


</head>
<body>


<marquee height="60px">Good Health brings happiness,satisfaction and makes life worthy!! </marquee>

<form class="button1" action="login.php" method="POST">

<button type="submit" name="submit">Login</button><br><br>
</form >

<form class="button2" action="signup.php" method="POST">
<button type="submit" name="submit">Sign-Up</button><br>
</form >

<img src="includes/diet.jpg"><img src="includes/diet1.jpg"></img>
<p>Health is wealth. There is nothing in our life that is more valuable than good health. Without health there is no happiness, no peace and no success. A person with bad health cannot enjoy the pleasure of being wealthy.

Health is more valuable than money. Money cannot buy health and happiness. But a healthy person remains in a state of bliss and happiness.

A healthy person is completely free from any illness or injury. A person with sound health enjoys a stable health that also includes a healthy mental condition. Our health depends upon several factors, such as food, pollution, sleeping habits, mental condition, air, water and sunlight. Morning walks and Physical exercises are very helpful for the fitness of our mind and body. We should take proper care of our health so that we can enjoy our life completely.

When we are ill or we do not want to play or work, our bad health robs us of sound sleep and appetite. Life becomes a burden for one, who is constantly ailing. Life has little charm for him. He feels tired of life, always complaining about one thing or the other.

On the other hand, one with good health enjoys his life. When he works or plays he is never tired. A healthy person enjoys good food and sound sleep. For him the world is beautiful and life is all joy.So what you guys are waiting for its a great opportunity for you just Sign Up without a second thought!!!!</p>
</body>
</html>