<?php
echo "0";
?>