<!--
All code is under the GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007.
-->

<?php
$db_host = "localhost";  // server to connect to.
$db_name = "login";  // the name of the database.
$db_user = "database username";  // mysql username to access the database with.
$db_pass = "database password";  // mysql password to access the database with.
$db_table = "users";    // the table that this script will set up and use.
?>
