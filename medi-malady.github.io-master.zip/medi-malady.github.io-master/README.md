# medi-malady.github.io
this is a website which provides medical authentication and trace location of nearby hostels,pharmacies and doctors
